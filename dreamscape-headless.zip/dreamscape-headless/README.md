# Dreamscape Aquariums – Headless Next.js Storefront

This repository contains a headless Shopify storefront built with Next.js 14 and Tailwind CSS. It is designed to power the Dreamscape Aquariums website, featuring immersive reef videos, animated coral drop countdowns and a beautiful product grid fetching data directly from Shopify via the Storefront API.

## Features

- **Headless architecture** – The frontend is completely decoupled from Shopify, allowing full control over the user experience.
- **Cinematic hero section** – Autoplaying reef video background with overlay text.
- **Coral drop countdown** – Displays a real‑time countdown to your next coral release using a simple React hook.
- **Product grid** – Fetches products from a collection via the Storefront API and displays them in responsive cards.
- **Tailwind CSS** – Rapid styling with utility classes and built‑in dark/light glassmorphism effects.

## Getting Started

1. **Install dependencies**

   ```bash
   pnpm install
   # or
   npm install
   # or
   yarn install
   ```

2. **Set environment variables**

   Copy `.env.example` to `.env.local` and replace the placeholder values:

   ```bash
   cp .env.example .env.local
   ```

   - `NEXT_PUBLIC_SHOPIFY_DOMAIN` – Your Shopify store domain, e.g. `your-store.myshopify.com` (without protocol).
   - `NEXT_PUBLIC_SHOPIFY_STOREFRONT_ACCESS_TOKEN` – The public Storefront API access token (from your Shopify admin under **Apps & sales channels → Develop apps**).
   - `NEXT_PUBLIC_CORAL_DROP_DATE` – The ISO string for your next coral drop, e.g. `2025-12-25T00:00:00Z`.

3. **Run the development server**

   ```bash
   npm run dev
   ```

   The site will be available at `http://localhost:3000`.

## Deployment

This project is ready to be deployed on [Vercel](https://vercel.com/) or any other Node.js hosting platform. Vercel will automatically detect the Next.js project. Make sure to set your environment variables in the hosting provider’s dashboard.

## Customize

- **Hero video** – Replace `public/reef-hero.mp4` with your own high‑quality reef footage.
- **Collection handles** – In `app/page.tsx` and `app/products/page.tsx`, update the collection handles passed to `getProductsByCollection` to match your Shopify collections (e.g. `'new-arrivals'`, `'all'`, etc.).
- **Styling** – Tailwind is fully configurable in `tailwind.config.js`. Feel free to add colors, fonts or plugins.

## Notes

This repository does not include a full cart/checkout implementation. You can add client‑side cart functionality using libraries like `@shopify/hydrogen-react` or by redirecting to the Shopify checkout via the Storefront API. The focus here is on showcasing how to structure a modern headless storefront with Next.js.

import Link from 'next/link';

export default function Navbar() {
  return (
    <nav className="bg-white/80 backdrop-blur sticky top-0 z-50 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
        <Link href="/" className="text-2xl font-bold text-cyan-600">Dreamscape</Link>
        <div className="flex space-x-4">
          <Link href="/products" className="text-gray-700 hover:text-cyan-600">Products</Link>
          <Link href="/about" className="text-gray-700 hover:text-cyan-600">About</Link>
          <Link href="/cart" className="text-gray-700 hover:text-cyan-600">Cart</Link>
        </div>
      </div>
    </nav>
  );
}

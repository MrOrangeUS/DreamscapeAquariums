'use client';
import { useEffect, useState } from 'react';

interface Props {
  targetDate: string;
}

interface TimeLeft {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}

export default function CountdownTimer({ targetDate }: Props) {
  function calculateTimeLeft(): TimeLeft | null {
    const target = new Date(targetDate).getTime();
    const now = new Date().getTime();
    const distance = target - now;
    if (distance <= 0) {
      return null;
    }
    return {
      days: Math.floor(distance / (1000 * 60 * 60 * 24)),
      hours: Math.floor((distance / (1000 * 60 * 60)) % 24),
      minutes: Math.floor((distance / 1000 / 60) % 60),
      seconds: Math.floor((distance / 1000) % 60),
    };
  }

  const [timeLeft, setTimeLeft] = useState<TimeLeft | null>(calculateTimeLeft());

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(calculateTimeLeft());
    }, 1000);
    return () => clearInterval(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [targetDate]);

  if (!timeLeft) {
    return <p className="text-cyan-500 font-semibold text-lg">The coral drop is live!</p>;
  }

  return (
    <div className="flex gap-4 text-center justify-center">
      {(['days', 'hours', 'minutes', 'seconds'] as Array<keyof TimeLeft>).map((unit) => (
        <div key={unit} className="flex flex-col items-center">
          <div className="text-3xl font-bold">{timeLeft[unit]}</div>
          <div className="uppercase text-xs">{unit}</div>
        </div>
      ))}
    </div>
  );
}

import React from 'react';

export default function Hero() {
  return (
    <section className="relative h-[60vh] w-full overflow-hidden">
      <video
        className="absolute top-0 left-0 w-full h-full object-cover"
        src="/reef-hero.mp4"
        autoPlay
        loop
        muted
        playsInline
      />
      <div className="absolute inset-0 bg-black/40 flex flex-col items-center justify-center text-center text-white p-4">
        <h1 className="text-4xl md:text-6xl font-bold mb-4 drop-shadow">Dreamscape Aquariums</h1>
        <p className="text-lg md:text-2xl max-w-2xl drop-shadow">Discover a world of vibrant corals, serene reefs, and underwater magic for your living space.</p>
      </div>
    </section>
  );
}

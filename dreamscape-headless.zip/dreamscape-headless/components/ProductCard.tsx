import Image from 'next/image';
import Link from 'next/link';
import { Product } from '../lib/shopify';

interface Props {
  product: Product;
}

export default function ProductCard({ product }: Props) {
  return (
    <div className="bg-white/80 backdrop-blur rounded-lg shadow-lg overflow-hidden flex flex-col">
      {product.image && (
        <Image
          src={product.image}
          alt={product.title}
          width={600}
          height={600}
          className="object-cover w-full h-48"
        />
      )}
      <div className="p-4 flex flex-col flex-1">
        <h3 className="text-xl font-semibold mb-2">{product.title}</h3>
        <p className="text-sm text-gray-700 mb-4 flex-1 line-clamp-3">{product.description}</p>
        <div className="flex items-center justify-between mt-auto">
          <span className="text-lg font-bold">{product.price}</span>
          <Link
            href={`/product/${product.handle}`}
            className="inline-block bg-cyan-500 hover:bg-cyan-600 text-white px-4 py-2 rounded-md text-sm transition"
          >
            View
          </Link>
        </div>
      </div>
    </div>
  );
}
